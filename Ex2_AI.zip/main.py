import game

if __name__ == '__main__':
    print("YAY LET'S START RUNNING STUFF")

    # PART1
    # game.play_game("human", "human")

    # PART2
    # game.play_tournament("greedy", "random", 50)
    # game.play_tournament("greedy_improved", "random", 50)
    # game.play_tournament("greedy", "greedy_improved", 50)
